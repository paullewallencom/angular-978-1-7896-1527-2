export const environment = {
  production: true,
  apiUrl: './assets/mocks/portfolios.json'
};
