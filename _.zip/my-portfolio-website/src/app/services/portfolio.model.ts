export interface Portfolio {
  id: number;
  name: string;
  description: string;
  type: string;
  preview: string;
}
